<?php 
//Pretty self explanatory, database connection information.
$host = "localhost";
//username for mysqldatabase
$user = "handyman_space";
//password for mysqldatabase
$pass = "V#EWLFFOxs_~";
//databasename for mysqldatabase
$dbname = "handyman_space";
?>