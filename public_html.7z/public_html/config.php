<?php
	//The home directory of this application. (for redirecting people)
	$home = "http://www.thehiddennation.com/space";
	//The website address (for redirecting people)
	$website = "www.thehiddennation.com";
	
	$tracking = false;
?>