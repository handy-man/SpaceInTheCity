<?PHP
include("../config.php");
header('Location: ' . $home . '');
?>