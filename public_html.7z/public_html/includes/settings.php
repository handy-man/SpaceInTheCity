<?php
	$login_enabled = true;
	$register_enabled = true;
?>