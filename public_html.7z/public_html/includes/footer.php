<div id="footer">
      <div style="padding-top: 15px;" class="container">
        <p class="text-muted-footer text-center">A Space In The City | Site by Nathan Hand <a href="#"><span class="glyphicon glyphicon-arrow-up"></span></a></p>
      </div>
</div>